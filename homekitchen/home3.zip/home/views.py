from django.template import loader
from django.shortcuts import render, get_list_or_404
from django.http import HttpResponse

from django.views.decorators.http import require_http_methods, require_GET, require_safe

@require_http_methods(["GET"])
def index(request, post_id=""):
    
    
    if post_id=="en":
                context = {
      'AboutUs':"ABOUT US",
      'ourProjects':"OUR PROJECTS",
      'Contactus':"CONTACT US",
      'languge':False,
      'langugee':"ARABIC",
      'hreflanguage':"../",
      'dirction':"ltr",
    #   '':"",
    #   '':"",
    #   '':"",
    #   '':"",
    #   '':"",
    #   '':"",
    #   '':"",
    #   '':"",
    #   '':"",
    #   '':"",
    #   '':"",
    #   '':"",
        }  
    else:
        context = {
            'AboutUs':"لماذا المحترف",
            'ourProjects':"مشروعنا",
            'Contactus':"اتصل بنا",
            'languge':True,
            'langugee':"ENGLISH",
            'hreflanguage':"en",
            'dirction':"rtl",
        }  

    return render(request, 'index.html', context)
    

